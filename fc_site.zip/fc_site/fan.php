<?php
require 'session.php';
<a href='about.php'>О клубе</a><br>


if ($_SESSION['role'] !== 'fan') {
    echo "Доступ запрещён.";
    exit();
}

echo "<h2>Добро пожаловать, фанат!</h2>";
echo "<p>Ваш email: {$_SESSION['email']}</p>";
echo "<a href='logout.php'>Выйти</a>";
?>