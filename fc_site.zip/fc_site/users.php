<?php
require 'session.php';
require 'db.php';
<a href='about.php'>О клубе</a><br>

if ($_SESSION['role'] !== 'admin') {
    echo "Доступ запрещён.";
    exit();
}

echo "<h2>Все пользователи</h2>";
$result = $conn->query("SELECT id, email, phone, role FROM users");

echo "<table border='1'><tr><th>ID</th><th>Email</th><th>Телефон</th><th>Роль</th></tr>";
while ($row = $result->fetch_assoc()) {
    echo "<tr><td>{$row['id']}</td><td>{$row['email']}</td><td>{$row['phone']}</td><td>{$row['role']}</td></tr>";
}
echo "</table><br><a href='logout.php'>Выйти</a>";

$conn->close();
?>