<?php
require 'db.php';

$email = $_POST['email'];
$phone = $_POST['phone'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);
$role = $_POST['role'];

$stmt = $conn->prepare("INSERT INTO users (email, phone, password, role) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $email, $phone, $password, $role);

if ($stmt->execute()) {
    echo "Регистрация успешна!<br><a href='login.php'>Войти</a>";
} else {
    echo "Ошибка: " . $conn->error;
}

$stmt->close();
$conn->close();
?>