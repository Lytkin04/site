<?php session_start(); ?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Вход</title>
</head>
<body>
<h2>Авторизация</h2>
<form action="login.php" method="post">
    <label>Email: <input type="email" name="email" required></label><br><br>
    <label>Пароль: <input type="password" name="password" required></label><br><br>
    <button type="submit">Войти</button>
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    require 'db.php';

    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();

    $res = $stmt->get_result();

    if ($res->num_rows === 1) {
        $user = $res->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['email'] = $user['email'];

            if ($user['role'] === 'admin') {
                header("Location: users.php");
            } else {
                header("Location: fan.php");
            }
            exit();
        } else {
            echo "<p>Неверный пароль.</p>";
        }
    } else {
        echo "<p>Пользователь не найден.</p>";
    }
}
?>
</body>
</html>